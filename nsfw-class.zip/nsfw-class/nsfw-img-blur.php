<?php
/*
Plugin Name: NSFW Image Class
Plugin URI: 
Description: NSFW Image Class - Simply assign any image on your site with the class "nsfw" and the plugin creates an overlay over the image to hide the image until the user clicks a button to view the image.
Version: 2.0
Author: Bilmartech
Author URI: 
*/
    
define('IMGBLUR_PATH', plugin_dir_path(__FILE__));

function themeslug_enqueue_style() {
    wp_enqueue_style( 'imgnsfw-css', plugins_url('/nsfw-class/imgnsfw.css', dirname(__FILE__)));
}

function themeslug_enqueue_script() {
    wp_enqueue_script( 'imgnsfw-js', plugins_url('/nsfw-class/imgnsfw.js', dirname(__FILE__)), array('jquery'), false, true );
    // Localize the script with new data
	wp_localize_script( 'imgnsfw-js', 'imgnsfwJson', array(
	    'nsfw_title_info' => get_option('nsfw_title_info', 'Graphic Content' ),
	    'nsfw_subtitle_info' => get_option('nsfw_subtitle_info', 'Click Button To See Image' ),
	    'button_text_info' => get_option('button_text_info', 'Show Me' ),
	    'button_background_color_info' => get_option('button_background_color_info', '#fd0505' ),
	    'button_font_color_info' => get_option('button_font_color_info', '#fff' )
	));
}

add_action( 'wp_enqueue_scripts', 'themeslug_enqueue_style' );
add_action( 'wp_enqueue_scripts', 'themeslug_enqueue_script' );

/*Admin Page*/

add_action( 'admin_menu', 'my_admin_menu' );

function my_admin_menu() {
	add_menu_page( 'NSFW Image Class', 'NSFW Image Menu', 'manage_options', 'nsfw_admin_page', 'nsfw_admin_page', 'dashicons-tickets', 6  );
    add_action( 'admin_init', 'nsfw_register_settings' );
}

function nsfw_register_settings() {	
    register_setting( 'nsfw_options', 'nsfw_title_info' );
    register_setting( 'nsfw_options', 'nsfw_subtitle_info' );
    register_setting( 'nsfw_options', 'button_text_info' );
    register_setting( 'nsfw_options', 'button_background_color_info' );
    register_setting( 'nsfw_options', 'button_font_color_info' );
}

include "nsfw-admin-page.php";