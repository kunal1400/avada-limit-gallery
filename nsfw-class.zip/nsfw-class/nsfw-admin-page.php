<?php
function nsfw_admin_page() { ?>
	<div class="wrap">
		<h2>NSFW Image Class Information</h2>
		<p> NSFW Image Class - Simply assign any image on your site with the class "nsfw" and the plugin creates an overlay over the image to hide the image until the user clicks a button to view the image.</p>
	
	<h2>NSFW Image Class Options</h2>

<form method="post" action="options.php">
<?php settings_fields( 'nsfw_options' ); ?>
<?php do_settings_sections( 'nsfw_options' ); ?>
<table class="form-table">

<tr valign="top"><th scope="row">Title:</th>
<td><input type="text" name="nsfw_title_info" value="<?php echo esc_attr(get_option('nsfw_title_info' )); ?>"/><label>  Default: Graphic Content</label></td></tr>

<tr valign="top"><th scope="row">Subtitle:</th>
<td><input type="text" name="nsfw_subtitle_info" value="<?php echo get_option('nsfw_subtitle_info' ); ?>"/><label>  Default: Click Button To See Image</label></td></tr>

<tr valign="top"><th scope="row">Button Text:</th>
<td><input type="text" name="button_text_info" value="<?php echo get_option('button_text_info' ); ?>"/><label>  Default: Show Me</label></td></tr>

<tr valign="top"><th scope="row">Button Background Color:</th>
<td><input type="text" name="button_background_color_info" value="<?php echo get_option('button_background_color_info' ); ?>"/><label>  Default: Red / #fd0505</label></td></tr>

<tr valign="top"><th scope="row">Button Font Color:</th>
<td><input type="text" name="button_font_color_info" value="<?php echo get_option('button_font_color_info' ); ?>"/><label>  Default: White / #fff</label></td></tr>

</table>
<?php submit_button(); 
?>
</form>
	</div>
	
<?php }