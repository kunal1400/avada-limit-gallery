window.onunload = function () {
	localStorage.removeItem('_clicked_nsfw');
}

function unique(array){
    return array.filter(function(el, index, arr) {
        return index === arr.indexOf(el);
    });
}

function getClosedNsfw() {
    return localStorage.getItem("_clicked_nsfw") ? JSON.parse(localStorage.getItem("_clicked_nsfw")) : [];
}

function setClosedNsfw(imgUrl) {
    let clicked_nsfw = localStorage.getItem("_clicked_nsfw") ? JSON.parse(localStorage.getItem("_clicked_nsfw")) : [];
    clicked_nsfw.push( imgUrl );
    clicked_nsfw = unique(clicked_nsfw);
    localStorage.setItem( "_clicked_nsfw", JSON.stringify(clicked_nsfw) );
}

jQuery(document).ready(function() {
  // Code for all imgs
  // .fusion-gallery-image a[href*="miuclass=nsfw"]
  jQuery('img.nsfw').each(function() {
    var currWidth   = jQuery(this).width();
    var currHeight  = jQuery(this).height();
    var classNames  = jQuery(this).attr('class').replace('nsfw','');
    jQuery(this).wrap('<div class="'+classNames+'" style="width:'+currWidth+'px;height:'+currHeight+'px;position:relative"></div>');
    jQuery(this).after('<div class="nsfw-warning" style="width:'+currWidth+'px;height:'+currHeight+'px;"><div class="nsfw-content"><p class="nsfw-title">'+imgnsfwJson.nsfw_title_info+'</p><p class="nsfw-subtitle">'+imgnsfwJson.nsfw_subtitle_info+'.</p><button style="background-color:'+imgnsfwJson.button_background_color_info+';color:'+imgnsfwJson.button_font_color_info+';" class="warning-btn">'+imgnsfwJson.button_text_info+'</button></div></div>');
  })

  // Code for all IDs
  jQuery('#nsfw img').each(function() {
    var currWidth   = jQuery(this).width();
    var currHeight  = jQuery(this).height();
    var classNames  = jQuery(this).attr('class').replace('nsfw','');
	  jQuery(this).addClass('nsfw')
    // jQuery(this).wrap('<div class="'+classNames+'" style="width:'+currWidth+'px;height:'+currHeight+'px;position:relative"></div>');
    jQuery(this).after('<div class="nsfw-warning" style="width:'+currWidth+'px;height:'+currHeight+'px;"><div class="nsfw-content"><p class="nsfw-title">'+imgnsfwJson.nsfw_title_info+'</p><p class="nsfw-subtitle">'+imgnsfwJson.nsfw_subtitle_info+'.</p><button style="background-color:'+imgnsfwJson.button_background_color_info+';color:'+imgnsfwJson.button_font_color_info+';" class="warning-btn">'+imgnsfwJson.button_text_info+'</button></div></div>');
  })

  // Popup continuously changing html to we also doing same :)
  setInterval(() => {
    applyNsfwOnPopups()
  }, 2000)
 })

 jQuery("body").on("click", '.warning-btn', function() {
   jQuery(this).closest('.nsfw-warning').hide();
   jQuery(this).closest('.nsfw-warning').siblings().toggleClass('nsfw');
   // jQuery(this).closest('.nsfw-warning').siblings().toggleClass('nsfw-closed');
 });

 /**
 * Popup nsfw code
 **/
 jQuery("body").on("click", '.popup-warning-btn', function() {
   if( jQuery(this).attr('data-img-src') ) {
     setClosedNsfw( jQuery(this).attr('data-img-src') )
   }
   jQuery(this).closest('.nsfw-warning').hide();
   // jQuery(this).closest('.nsfw-warning').addClass("nsfw-warning-closed");
 });

 function applyNsfwOnPopups() {
    jQuery('.ilightbox-container img[src*="miuclass=nsfw"]').each(function() {
      let currWidth   = jQuery(this).width();
      let currHeight  = jQuery(this).height();
      let clickedImgSrc = jQuery(this).attr("src");
      let getClosedNsfw = localStorage.getItem("_clicked_nsfw") ? JSON.parse(localStorage.getItem("_clicked_nsfw")) : [];

      console.log(getClosedNsfw.indexOf(clickedImgSrc), "getClosedNsfw")

      if ( jQuery(this).parent().find(".nsfw-warning").length == 0 && getClosedNsfw.indexOf(clickedImgSrc) === -1 ) {
        jQuery(this).after('<div class="nsfw-warning" style="width:100%;height:auto;position: absolute;top: 0;z-index: 999;bottom: 0;"><div class="nsfw-content"><p class="nsfw-title">'+imgnsfwJson.nsfw_title_info+'</p><p class="nsfw-subtitle">'+imgnsfwJson.nsfw_subtitle_info+'.</p><button style="background-color:'+imgnsfwJson.button_background_color_info+';color:'+imgnsfwJson.button_font_color_info+';" class="popup-warning-btn" data-img-src="'+clickedImgSrc+'">'+imgnsfwJson.button_text_info+'</button></div></div>');
      }
    })
  }

  jQuery('.fusion-gallery-image a[href*="miuclass=nsfw"] img').each(function() {
    let currWidth   = jQuery(this).width();
    let currHeight  = jQuery(this).height();
    let clickedImgSrc = jQuery(this).attr("src");

    if (currWidth && currWidth > 0 ) {
      var classNames  = jQuery(this).attr('class').replace('nsfw','');
      jQuery(this).parent().after('<div class="nsfw-warning" style="width:100%;height:auto;position: absolute;top: 0;z-index: 999;bottom: 0;"><div class="nsfw-content"><p class="nsfw-title">'+imgnsfwJson.nsfw_title_info+'</p><p class="nsfw-subtitle">'+imgnsfwJson.nsfw_subtitle_info+'.</p><button style="background-color:'+imgnsfwJson.button_background_color_info+';color:'+imgnsfwJson.button_font_color_info+';" class="warning-btn" data-img-src="'+clickedImgSrc+'">'+imgnsfwJson.button_text_info+'</button></div></div>');
    }
  })
  /*** END ***/
